import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=pathToFileURL(process.cwd()+'/');
const {loadCardScripts,loadCardScenarios}=await import(new URL('game/tools/engine-cards.mjs',root));
const {cardCheckSource,cardInputHashes}=await import(new URL('game/tools/card-check-policy.mjs',root));
const sha=raw=>createHash('sha256').update(raw).digest('hex');
const source=cardCheckSource(process.cwd());assert.equal(source.dirty,false);
const after=JSON.parse(fs.readFileSync('../scratch/rob-316-mixed-after-4995a7ce.json','utf8'));
const manifest=JSON.parse(fs.readFileSync('../scratch/rob-316-selected1521-manifest.json','utf8'));
const frozen=JSON.parse(fs.readFileSync('../scratch/rob-316-mixed-validation-input-033cd059.json','utf8'));
const diff=JSON.parse(fs.readFileSync('../scratch/rob-316-exact2743-diff.json','utf8'));
const scripts=loadCardScripts().map(e=>e.script).filter(script=>manifest.names.includes(script.identity.name));
const files=loadCardScenarios().map(e=>e.scenarios).filter(file=>manifest.names.includes(file.card));
assert.equal(scripts.length,1521);assert.equal(files.length,1521);assert.equal(files.reduce((n,f)=>n+f.scenarios.length,0),4337);
assert.deepEqual(cardInputHashes(scripts,files),after.source.inputs);
const expected=new Map(diff.files.map(file=>[file.file,file.afterSha256]));
for(const file of frozen.scenarioFileInputs)assert.equal(sha(fs.readFileSync(file.file)),expected.get(file.file)??file.sha256);
for(const file of frozen.runtime.files)assert.equal(sha(fs.readFileSync(file.file)),file.sha256);
assert.equal(execFileSync('git',['diff','--name-only','4995a7ce','HEAD','--','game/engine','game/tools','data/engine'],{encoding:'utf8'}).trim(),'');
assert.equal(execFileSync('git',['diff','--name-only','dacd3803a9d3c590ccaf19b30e728f7349c50f8a','HEAD','--','docs/ACTIVE.md'],{encoding:'utf8'}).trim(),'');
const result={schema:'ROB316FinalInputAudit@1',source,dependency:'dacd3803a9d3c590ccaf19b30e728f7349c50f8a',
 historicalBefore:'033cd059eb5150493015de042309e11ae83ad7da',historicalAfter:after.source.revision,
 selectedScripts:1521,selectedScenarioFiles:1521,allOriginalSelectedScenarios:4337,selectedInputs:cardInputHashes(scripts,files),
 selectedInputsMatchCleanAfter:true,all6430ScenarioHashesMatchApprovedState:true,all77RuntimeHashesUnchanged:true,
 helperRulesDefinitionsClassifierUnchanged:true,ownerActiveMatchesDependency:true,
 editedScenarios:2743,sourceFields:6741,all681RejectedScenariosUntouched:true,cardAdmissions:0};
fs.writeFileSync('../scratch/rob-316-final-input-audit.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
