import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import crypto from 'node:crypto';
const before='033cd059eb5150493015de042309e11ae83ad7da',after='4995a7cebf3a3086de71862bc572467c15073bf2';
const git=(args,options={})=>execFileSync('git',args,{maxBuffer:256*1024*1024,...options});
const cohort=JSON.parse(fs.readFileSync('../scratch/v8-mixed-source-cohort-9c4fa115.json'));
const resultsRaw=fs.readFileSync('../scratch/rob-316-mixed-results-033cd059.jsonl');
assert.equal(crypto.createHash('sha256').update(resultsRaw).digest('hex'),'dbb705847a71a5dd31130e82bd173a68219c8ba75922efe81e6a2abeb41a878e');
const rows=resultsRaw.toString('utf8').trim().split('\n').map(JSON.parse);
const plans=new Map();
for(const row of rows)if(row.result.eligibleForSavedEdit){
 const c=cohort.candidates[row.originalCohortOrdinal];assert.equal(c.ordinal,row.originalCohortOrdinal);
 if(!plans.has(c.file))plans.set(c.file,[]);plans.get(c.file).push(c);
}
assert.equal(plans.size,1521);
const changed=git(['-c','core.quotepath=false','diff','--name-only',before,after],{encoding:'utf8'}).trim().split('\n');
assert.deepEqual(changed.sort(),[...plans.keys()].sort(),'only the exact eligible scenario files may change');
function tree(ref){return new Map(git(['ls-tree','-r',ref,'--','game/engine/cards'],{encoding:'utf8'}).trim().split('\n').map(line=>{const at=line.indexOf('\t');return [line.slice(at+1),line.slice(0,at).split(' ')[2]];}));}
const oldTree=tree(before),newTree=tree(after);
assert.deepEqual([...oldTree.keys()],[...newTree.keys()]);
const scenarioFiles=[...oldTree.keys()].filter(p=>p.endsWith('.scenarios.json'));assert.equal(scenarioFiles.length,6430);
for(const [file,oid]of oldTree)if(!plans.has(file))assert.equal(newTree.get(file),oid,`unchanged blob ${file}`);
const ids=[...new Set(changed.flatMap(file=>[oldTree.get(file),newTree.get(file)]))];
const batch=git(['cat-file','--batch'],{input:ids.join('\n')+'\n'}),blobs=new Map();
let cursor=0;
for(const id of ids){const end=batch.indexOf(10,cursor),header=batch.subarray(cursor,end).toString('ascii').split(' ');assert.equal(header[0],id);assert.equal(header[1],'blob');const size=Number(header[2]);cursor=end+1;blobs.set(id,batch.subarray(cursor,cursor+size));cursor+=size;assert.equal(batch[cursor++],10);}
assert.equal(cursor,batch.length);
let scenarios=0,fields=0;
for(const file of changed){
 const original=JSON.parse(blobs.get(oldTree.get(file)).toString('utf8'));
 const expected=structuredClone(original),actual=JSON.parse(blobs.get(newTree.get(file)).toString('utf8'));
 for(const c of plans.get(file)){assert.deepEqual(original.scenarios[c.scenarioIndex],c.original);assert.deepEqual(original.fixtures??{},c.fixtures);expected.scenarios[c.scenarioIndex]=c.changed;scenarios++;fields+=c.additions.length;}
 assert.deepEqual(actual,expected,`complete original-field preservation in ${file}`);
}
assert.equal(scenarios,2743);assert.equal(fields,6741);
const evidence={schema:'RootROB316ActualGitBatchAudit@1',before,after,files:changed.length,scenarios,literalSourceFields:fields,allOriginalJSONFieldsPreserved:true,allOtherCardBlobsIdentical:true,all6430ScenarioFilesAccountedFor:true,runtimeOrDefinitionEdits:0,scope:'exact approved scenario-witness repairs only; no card admission or canonical gate credit'};
fs.writeFileSync('../scratch/rob-316-root-actual-4995.json',JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence));
