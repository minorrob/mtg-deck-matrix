"""Mixed-board proposal: only structural scope changes; no native cohort execution or saved edits."""
from pathlib import Path
from copy import deepcopy
from collections import Counter
import ast,hashlib,json,subprocess
outside=Path.cwd().parent/'scratch';source='9c4fa1156fe482b324488d51627cfc15e0d4583a'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
metadata=json.loads((outside/'v8-mixed-source-metadata-9c4fa115.json').read_bytes())
assert metadata['source']['revision']==source and metadata['source']['dirty'] is False
basic={'Wastes','Plains','Island','Swamp','Mountain','Forest'};permanent={'Creature','Artifact','Enchantment','Land','Planeswalker','Battle'}
def support_metadata(name,fixtures):
    if name in fixtures:
        definition=fixtures[name]
        return {'types':definition.get('types',[]),'manaTriggers':[a for a in definition.get('abilities',[]) if a.get('trigger',{}).get('manaAbility')],'fixture':True}
    value=metadata['definitions'].get(name)
    return {**value,'fixture':False} if value else {'types':[],'manaTriggers':[],'fixture':False,'unresolved':True}
def support_is_permanent(name,fixtures):
    if name in basic:return True
    types=support_metadata(name,fixtures)['types']
    return bool(permanent&set(types)) and not {'Instant','Sorcery'}&set(types)
planner_raw=(outside/'v8-basic-source-repair.py').read_text(encoding='utf-8')
tree=ast.parse(planner_raw);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='plan')
old_function=ast.get_source_segment(planner_raw,node)
old_guard="    if any(e.get('zone')=='command' or e.get('zone')=='battlefield' and any(n not in basic or n in fixtures for n in e['cards']) for e in setup): return None"
new_guard="    if any(e.get('zone')=='command' for e in setup) or any(name in fixtures for name in basic) or any(e.get('zone')=='battlefield' and any(not support_is_permanent(name,fixtures) for name in e['cards']) for e in setup): return None"
assert old_function.count(old_guard)==1
proposed_function=old_function.replace(old_guard,new_guard)
assert proposed_function.replace(new_guard,old_guard)==old_function
namespace={'deepcopy':deepcopy,'basic':basic,'support_is_permanent':support_is_permanent}
exec(compile(proposed_function,'<proposal-only-scope-change>','exec'),namespace);plan=namespace['plan']
sha=lambda raw:hashlib.sha256(raw).hexdigest()
canonical=lambda value:json.dumps(value,ensure_ascii=False,separators=(',',':')).encode('utf-8')
candidates=[];dispositions=[];files=[]
for file in sorted(Path('game/engine/cards').rglob('*.scenarios.json')):
    raw=file.read_bytes();data=json.loads(raw);fixtures=data.get('fixtures',{});name=str(file).replace('\\','/')
    files.append({'file':name,'sha256':sha(raw),'scenarios':len(data.get('scenarios',[]))})
    for scenario_index,original in enumerate(data.get('scenarios',[])):
        identity={'file':name,'card':data.get('card'),'scenarioIndex':scenario_index,'scenario':original.get('name')}
        setup=original.get('setup',[]);reasons=[]
        companions=[{'name':n,'seat':e.get('seat'),**support_metadata(n,fixtures)} for e in setup if e.get('zone')=='battlefield' for n in e['cards'] if n not in basic]
        if original.get('at',{'turn':1,'phase':'MAIN1'})!={'turn':1,'phase':'MAIN1'}:reasons.append('nondefault-initial-stage')
        if any(e.get('zone')=='command' for e in setup):reasons.append('command-zone-setup-excluded')
        if basic&set(fixtures):reasons.append('any-basic-land-fixture-override-excluded')
        if any(not support_is_permanent(c['name'],fixtures) for c in companions):reasons.append('nonpermanent-or-unresolved-battlefield-support-excluded')
        if reasons:dispositions.append({**identity,'disposition':'outside-proposed-scope','reasons':reasons});continue
        counts=Counter(n for e in setup if e.get('zone')=='battlefield' and e.get('seat')==0 for n in e['cards']);used=Counter();prefix=[];rejection=[];existing=[]
        for i,step in enumerate(original.get('steps',[])):
            if step.get('tap') not in basic or step.get('seat',0)!=0 or set(step)-{'tap','seat','source','mana'}:break
            card=step['tap'];ordinal=used[card];literal={'zone':'battlefield','index':ordinal}
            if ordinal>=counts[card]:rejection.append('prefix-exceeds-authored-physical-sources');break
            if 'source' in step:
                if step['source']!=literal:rejection.append('existing-literal-differs-from-authored-ordinal');break
                existing.append({'step':i,'literalBytes':json.dumps(step['source']).encode().hex()})
            prefix.append({'step':i,'name':card,'ordinal':ordinal,'added':'source' not in step});used[card]+=1
        planned=plan(original,fixtures)
        if rejection:assert planned is None;dispositions.append({**identity,'disposition':'rejected-by-planner','reasons':rejection});continue
        assert planned is not None
        changed,additions=planned
        for literal in existing:assert json.dumps(changed['steps'][literal['step']]['source']).encode().hex()==literal['literalBytes']
        if not prefix:dispositions.append({**identity,'disposition':'no-initial-prefix','reasons':['no-initial-contiguous-actor0-basic-taps']});continue
        if not additions:dispositions.append({**identity,'disposition':'already-explicit','existingLiterals':existing});continue
        restored=deepcopy(changed)
        for addition in additions:del restored['steps'][addition['step']]['source']
        assert restored==original
        at=len(candidates)
        candidates.append({**identity,'ordinal':at,'fileSha256':sha(raw),'originalScenarioSha256':sha(canonical(original)),
          'fixtureSha256':sha(canonical(fixtures)),'plannedScenarioSha256':sha(canonical(changed)),
          'fixtures':fixtures,'original':original,'changed':changed,'prefix':prefix,'additions':additions,
          'existingLiterals':existing,'companions':companions,'newMixedBoard':bool(companions),'allOriginalFieldsPreserved':True})
        dispositions.append({**identity,'disposition':'new-mixed-candidate' if companions else 'remaining-basic-only-candidate','candidateOrdinal':at,'missingReferences':len(additions)})
assert len(dispositions)==metadata['scenarioCount']
mixed=[c for c in candidates if c['newMixedBoard']];selected=[];categories=[]
def take(label,predicate):
    candidate=next((c for c in mixed if c['ordinal'] not in selected and predicate(c)),None)
    categories.append({'category':label,'candidateOrdinal':candidate['ordinal'] if candidate else None,'present':candidate is not None})
    if candidate:selected.append(candidate['ordinal'])
def has(c,name):return any(p['name']==name for p in c['companions'])
def taps(c,name):return any(p['name']==name for p in c['prefix'])
def modifier(c):return any(p['manaTriggers'] for p in c['companions'])
take('actual Crypt Ghast modifier with Swamp',lambda c:has(c,'Crypt Ghast') and taps(c,'Swamp'))
take('actual Forsaken Monument modifier with Wastes',lambda c:has(c,'Forsaken Monument') and taps(c,'Wastes'))
take('actual Zendikar Resurgent modifier with basic tap',lambda c:has(c,'Zendikar Resurgent'))
take('actual Urborg source-grant board',lambda c:has(c,'Urborg, Tomb of Yawgmoth'))
for card_type in ['Creature','Artifact','Enchantment']:
    take('ordinary '+card_type+' companion',lambda c,t=card_type:not modifier(c) and any(t in p['types'] for p in c['companions']))
take('three nonbasic companions with varied types',lambda c:not modifier(c) and len(c['companions'])>=3 and len({t for p in c['companions'] for t in p['types']})>=2)
take('opponent nonbasic companion',lambda c:not modifier(c) and any(p['seat']!=0 for p in c['companions']))
take('multiple-type companion',lambda c:not modifier(c) and any(len(permanent&set(p['types']))>=2 for p in c['companions']))
while len(selected)<10:take('pre-execution first-unused fallback for absent category',lambda c:True)
assert len(selected)==10 and len(set(selected))==10
cohort={'schema':'V8MixedBoardSourceProposal@1','scope':'structural proposal only; no wider native validation or saved edits',
 'source':metadata['source'],'originalPlannerFunctionSha256':sha(old_function.encode()),'proposedPlannerFunctionSha256':sha(proposed_function.encode()),
 'originalPlannerGuard':old_guard,'proposedPlannerGuard':new_guard,'onlyPlannerScopeGuardChanged':True,
 'candidateCount':len(candidates),'newMixedCandidates':len(mixed),'newMixedFiles':len({c['file'] for c in mixed}),
 'newMixedReferenceAdditions':sum(len(c['additions']) for c in mixed),'remainingBasicOnlyCandidates':len(candidates)-len(mixed),
 'allScenarioDispositions':dispositions,'scenarioFileInputs':files,'candidates':candidates,
 'fixedPilotSelection':categories,'fixedPilotCandidateOrdinals':selected}
raw=(json.dumps(cohort,ensure_ascii=False,indent=2)+'\n').encode();(outside/'v8-mixed-source-cohort-9c4fa115.json').write_bytes(raw)
pilot={'source':metadata['source'],'cohortSha256':sha(raw),'scope':'exact fixed ten only; unchanged native validation; no replacement',
 'selection':categories,'originalCohortOrdinals':selected,'candidates':[candidates[at] for at in selected]}
(outside/'v8-mixed-source-pilot-input-9c4fa115.json').write_bytes((json.dumps(pilot,ensure_ascii=False,indent=2)+'\n').encode())
summary={k:cohort[k] for k in ['source','candidateCount','newMixedCandidates','newMixedFiles','newMixedReferenceAdditions','remainingBasicOnlyCandidates','fixedPilotSelection','fixedPilotCandidateOrdinals']}
summary['cohortSha256']=sha(raw);summary['dispositions']=dict(Counter(d['disposition'] for d in dispositions))
(outside/'v8-mixed-source-cohort-summary-9c4fa115.json').write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps(summary,ensure_ascii=True,indent=2))
