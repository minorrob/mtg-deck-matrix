from pathlib import Path
import ast, collections, copy, gzip, hashlib, json, re, subprocess

root = Path.cwd()
outside = root.parent / 'scratch'
revision = '033cd059eb5150493015de042309e11ae83ad7da'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda name: json.loads((outside / name).read_bytes())
write = lambda name, value: (outside / name).write_bytes((json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
input_name = 'rob-316-mixed-validation-input-033cd059.json'
result_name = 'rob-316-mixed-results-033cd059.jsonl'
frozen, summary = read(input_name), read('rob-316-mixed-summary-033cd059.json')
rows = [json.loads(line) for line in (outside / result_name).read_bytes().splitlines()]
assert sha((outside / input_name).read_bytes()) == summary['inputSha256']
assert sha((outside / result_name).read_bytes()) == summary['resultsSha256']
assert len(rows) == len(frozen['candidates']) == summary['completed'] == 3263
assert summary['complete'] and summary['inputsUnchanged']
for entry in frozen['scenarioFileInputs'] + frozen['runtime']['files']:
    assert sha((root / entry['file']).read_bytes()) == entry['sha256'], entry['file']
assert sha((root / 'docs/ACTIVE.md').read_bytes()) == frozen['frozenActiveSha256']
assert sha((outside / 'v8-basic-source-inventory-worker.mjs').read_bytes()) == frozen['runtime']['workerRawSha256']
cohort = read('v8-mixed-source-cohort-9c4fa115.json')
historical = read('v8-mixed-source-pilot-results-9c4fa115.json')
assert historical['results'] == frozen['historicalPilot']['all10Results']
assert len(frozen['historicalPilot']['fourUnproved']) == 4
eligible, rejected = [], []
all_receipts = 0
for ordinal, (plan, row) in enumerate(zip(frozen['candidates'], rows)):
    result = row['result']
    assert row['runOrdinal'] == ordinal and row['originalCohortOrdinal'] == plan['ordinal']
    assert row['source'] == revision and row['inputSha256'] == summary['inputSha256']
    assert result['file'] == plan['file'] and result['card'] == plan['card']
    assert result['scenario'] == plan['original']['name']
    assert result['inputsUnchanged'] and result['originalFieldsPreserved']
    restored = copy.deepcopy(plan['changed'])
    for addition in plan['additions']:
        assert 'source' not in plan['original']['steps'][addition['step']]
        assert restored['steps'][addition['step']]['source'] == addition['source']
        del restored['steps'][addition['step']]['source']
    assert restored == plan['original']
    for literal in plan['existingLiterals']:
        assert plan['changed']['steps'][literal['step']]['source'] == plan['original']['steps'][literal['step']]['source']
    all_receipts += len(result.get('nativeReceipts', []))
    if result.get('eligibleForSavedEdit'):
        assert result['nativePrefixVerified'] and result['fullStrictPass']
        assert len(result['nativeReceipts']) == len(plan['prefix'])
        eligible.append({'runOrdinal': ordinal, 'originalCohortOrdinal': plan['ordinal'], 'file': plan['file'],
                         'card': plan['card'], 'scenarioIndex': plan['scenarioIndex'], 'scenario': result['scenario'],
                         'additions': plan['additions'], 'existingLiterals': plan['existingLiterals'],
                         'assertions': result['assertions'], 'nativeReceiptCount': len(result['nativeReceipts'])})
    else:
        kind = 'native-prefix' if result.get('prefixFailure') else 'full-strict' if result.get('fullFailure') else 'execution'
        rejected.append({'runOrdinal': ordinal, 'originalCohortOrdinal': plan['ordinal'], 'kind': kind, 'result': result})
assert len(eligible) == 2743 and len(rejected) == 520
assert len({row['file'] for row in eligible}) == 1521
assert sum(len(row['additions']) for row in eligible) == 6741
assert sum(row['assertions'] for row in eligible) == 7255
assert sum(row['nativeReceiptCount'] for row in eligible) == 6741
assert all_receipts == 7738
assert collections.Counter(row['kind'] for row in rejected) == {'native-prefix': 52, 'full-strict': 468}
write('rob-316-mixed-eligible-033cd059.json', {'scope': 'review only; no saved edits authorized', 'source': revision, 'eligible': eligible})
write('rob-316-mixed-rejections-033cd059.json', {'source': revision, 'rejected': rejected})
sample_positions = [i * (len(eligible) - 1) // 10 for i in range(11)]
samples = []
for position in sample_positions:
    entry = eligible[position]
    plan = frozen['candidates'][entry['runOrdinal']]
    samples.append({'eligiblePosition': position, **entry, 'fixtures': plan['fixtures'],
                    'original': plan['original'], 'proposed': plan['changed'],
                    'result': rows[entry['runOrdinal']]['result']})
write('rob-316-mixed-review-samples-033cd059.json', {'selection': 'first, last, and nine evenly spaced integer positions in entire fixed eligible order; no substitutions', 'samples': samples})
pilot_current = []
by_ordinal = {row['originalCohortOrdinal']: row for row in rows}
for old in historical['results']:
    current = by_ordinal[old['cohortOrdinal']]
    pilot_current.append({'originalCohortOrdinal': old['cohortOrdinal'], 'historical': old, 'current': current})
write('rob-316-mixed-pilot-comparison-033cd059.json', {'historicalSource': historical['source'], 'currentSource': revision,
      'originalHistoricalTenRetainedExactly': True, 'historicalFourRefusalsNotErased': True, 'comparisons': pilot_current})
audit = read('v8-mixed-root-structural-audit-e284.json')
assert (audit['eligibleScenarios'], audit['eligibleFiles'], audit['eligibleFields'], audit['originalAssertions']) == (2743, 1521, 6741, 7255)
assert audit['nativeReceiptsIndependentlyAudited'] == 6741
tree = ast.parse((outside / 'scan-pool-368a.py').read_text(encoding='utf-8'))
patterns = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'patterns' for t in n.targets))
names = [input_name, result_name, 'rob-316-mixed-validation-binding-033cd059.json', 'rob-316-mixed-summary-033cd059.json',
         'rob-316-mixed-checkpoint-033cd059.json', 'rob-316-mixed-run-033cd059.log',
         'rob-316-mixed-eligible-033cd059.json', 'rob-316-mixed-rejections-033cd059.json',
         'rob-316-mixed-review-samples-033cd059.json', 'rob-316-mixed-pilot-comparison-033cd059.json',
         'rob-316-freeze-mixed-validation.mjs', 'rob-316-run-mixed-validation.mjs', 'rob-316-package-mixed-validation.py',
         'v8-basic-source-inventory-worker.mjs', 'v8-basic-source-inventory-worker-build.json',
         'v8-mixed-source-cohort-9c4fa115.json', 'v8-mixed-source-cohort-summary-9c4fa115.json',
         'v8-mixed-source-pilot-input-9c4fa115.json', 'v8-mixed-source-pilot-results-9c4fa115.json',
         'v8-mixed-source-pilot-run-9c4fa115.log', 'v8-mixed-source-package-9c4fa115.json',
         'v8-mixed-source-metadata.mjs', 'v8-mixed-source-freeze.py', 'v8-mixed-source-pilot-run.mjs',
         'v8-mixed-root-structural-audit.py', 'v8-mixed-root-structural-audit-e284.json']
artifacts = []
for name in names:
    raw = (outside / name).read_bytes()
    assert not any(re.search(pattern, raw.decode('utf-8-sig'), re.I) for pattern in patterns), 'privacy finding: ' + name
    packed = gzip.compress(raw, mtime=0)
    assert gzip.decompress(packed) == raw
    target = outside / (name + '.gz')
    if target.exists():
        assert target.read_bytes() == packed, 'refuse to replace differing historical gzip: ' + name
    else:
        target.write_bytes(packed)
    artifacts.append({'file': name, 'bytes': len(raw), 'sha256': sha(raw), 'gzip': target.name,
                      'gzipBytes': len(packed), 'gzipSha256': sha(packed), 'roundtripVerified': True, 'rawPrivacyScanPassed': True})
package = {'schema': 'ROB316MixedValidationPackage@1', 'issue': 'ROB-316', 'source': frozen['source'],
           'scope': 'immutable read-only complete fixed-cohort validation; review required before any saved edit',
           'runtime': frozen['runtime'], 'cohortSha256': summary['cohortSha256'], 'inputSha256': summary['inputSha256'],
           'resultsSha256': summary['resultsSha256'], 'originalPlannerFunctionSha256': cohort['originalPlannerFunctionSha256'],
           'proposedPlannerFunctionSha256': cohort['proposedPlannerFunctionSha256'], 'onlyPlannerScopeGuardChanged': True,
           'candidateCount': 3263, 'excludedPriorBasicRejects': 161,
           'reviewEligibleScenarios': 2743, 'reviewEligibleFiles': 1521, 'reviewProposedFieldAdditions': 6741,
           'originalAssertionsPassed': 7255, 'eligibleNativeTapReceipts': 6741, 'allCasesNativeTapReceipts': 7738,
           'prefixFailures': 52, 'fullStrictFailures': 468, 'executionFailures': 0, 'timeouts': 0,
           'historicalFixedTen': {'source': historical['source'], 'ordinals': historical['fixedCohortOrdinals'],
                                  'originalTenRetained': True, 'originalFourRefusalsRetained': True},
           'independentRootAudit': audit,
           'rootAuditCountingCorrection': 'Root initially compared eligible receipts with all-case receipts; separate explicit counts corrected this bookkeeping assertion. No native credit changed.',
           'all6430ScenarioHashesUnchanged': True, 'allRuntimeHashesUnchanged': True, 'frozenActiveUnchanged': True,
           'savedEdits': 0, 'omissionRuns': 0, 'gateChanges': 0, 'cardsAdmitted': 0, 'canonicalAcceptance': False,
           'interactionConfidence': 'Finite native witness evidence does not establish exhaustive interaction support or permit card addition/promotion.',
           'privacyCategories': 'same eight credential/personal-address categories as local-ci.sh', 'artifacts': artifacts}
write('rob-316-mixed-package-033cd059.json', package)
package_raw = (outside / 'rob-316-mixed-package-033cd059.json').read_bytes()
assert not any(re.search(pattern, package_raw.decode('utf-8'), re.I) for pattern in patterns)
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
print(json.dumps({'package': 'rob-316-mixed-package-033cd059.json', 'sha256': sha(package_raw), 'artifacts': len(artifacts),
                  'gzipRoundtrips': len(artifacts), 'privacy': 'PASS', 'sourceClean': True,
                  'eligibleScenarios': 2743, 'rejections': 520, 'eligibleTapReceipts': 6741, 'allTapReceipts': 7738}, indent=2))
