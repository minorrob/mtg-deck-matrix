from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();outside=root.parent/'scratch'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda name:json.loads((outside/name).read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='033cd059eb5150493015de042309e11ae83ad7da'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
package=read('rob-316-mixed-package-033cd059.json')
assert sha((outside/'rob-316-mixed-package-033cd059.json').read_bytes())=='ff15f1cd7e2ed5d142cc5909dbcdc89e0343c5e3b0d711c6e461fdd89fd90582'
eligible=read('rob-316-mixed-eligible-033cd059.json')['eligible'];frozen=read('rob-316-mixed-validation-input-033cd059.json')
names=sorted({entry['card'] for entry in eligible});files=sorted({entry['file'] for entry in eligible})
assert len(names)==len(files)==1521 and len(eligible)==2743
records=[]
for file in files:
    raw=(root/file).read_bytes();doc=json.loads(raw)
    assert doc['card'] in names
    records.append({'file':file,'card':doc['card'],'sha256':sha(raw),'originalScenarios':len(doc['scenarios'])})
for entry in frozen['scenarioFileInputs']+frozen['runtime']['files']:assert sha((root/entry['file']).read_bytes())==entry['sha256']
name_hash=sha(json.dumps(names,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
manifest={'schema':'ROB316SelectedManifest@1','source':frozen['source'],'scope':'exact full 1521 card identities and every original saved scenario/ability; diagnostic only',
 'names':names,'namesSha256':name_hash,'files':records,'allOriginalScenarios':sum(r['originalScenarios'] for r in records),
 'editedScenarios':2743,'approvedAdditions':6741,'reviewPackageSha256':sha((outside/'rob-316-mixed-package-033cd059.json').read_bytes()),
 'renamedOrNormalized':False,'cardsAdmitted':0}
for name,value in [('rob-316-selected1521-names.json',names),('rob-316-selected1521-manifest.json',manifest)]:
    target=outside/name;raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    if target.exists():assert target.read_bytes()==raw
    else:target.write_bytes(raw)
print(json.dumps({'cards':1521,'scenarios':manifest['allOriginalScenarios'],'namesSha256':name_hash,'manifestSha256':sha((outside/'rob-316-selected1521-manifest.json').read_bytes()),'sourceClean':True},indent=2))
