import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const sha=raw=>createHash('sha256').update(raw).digest('hex');
const root=pathToFileURL(process.cwd()+'/');
const {main}=await import(new URL('game/tools/batch/check-cards.mjs',root));
const eligibleRaw=fs.readFileSync('../scratch/rob-316-mixed-eligible-033cd059.json');
const packageRaw=fs.readFileSync('../scratch/rob-316-mixed-package-033cd059.json');
assert.equal(sha(packageRaw),'ff15f1cd7e2ed5d142cc5909dbcdc89e0343c5e3b0d711c6e461fdd89fd90582');
const review=JSON.parse(packageRaw.toString('utf8'));
assert.equal(sha(eligibleRaw),review.artifacts.find(a=>a.file==='rob-316-mixed-eligible-033cd059.json').sha256);
const eligible=JSON.parse(eligibleRaw.toString('utf8')).eligible;
const names=JSON.parse(fs.readFileSync('../scratch/rob-316-selected1521-names.json','utf8'));
assert.equal(names.length,1521);assert.equal(new Set(names).size,1521);
const expected=[...new Set(eligible.map(candidate=>candidate.card))].sort();
assert.deepEqual(names,expected);
const nameHash=sha(Buffer.from(JSON.stringify(names)));
const manifest=JSON.parse(fs.readFileSync('../scratch/rob-316-selected1521-manifest.json','utf8'));
assert.equal(nameHash,manifest.namesSha256);assert.deepEqual(names,manifest.names);
fs.writeFileSync('../scratch/rob-316-selected1521-transport.json',JSON.stringify({cards:1521,fullIdentityStringsExact:true,
  namesSha256:nameHash,reviewPackageSha256:sha(packageRaw),eligibleSha256:sha(eligibleRaw),
  renamedOrNormalized:false,checker:'unchanged public check-cards.mjs exported main; supported argv; strict runtime-removal proof enabled'},null,2)+'\n');
assert.equal(typeof process.argv[2],'string');
console.log(JSON.stringify({masterPid:process.pid,selection:1521,namesSha256:nameHash}));
process.exitCode=main(['--cards',names.join('|'),'--ability-ledger',path.resolve(process.argv[2]),'--counterfactual']);
