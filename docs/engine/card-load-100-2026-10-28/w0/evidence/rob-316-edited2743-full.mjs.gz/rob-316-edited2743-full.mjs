import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=pathToFileURL(process.cwd()+'/');
const {loadCardIndex}=await import(new URL('game/tools/engine-cards.mjs',root));
const {runScenario}=await import(new URL('game/engine/cards/scenario.mjs',root));
const eligible=JSON.parse(fs.readFileSync('../scratch/rob-316-mixed-eligible-033cd059.json','utf8')).eligible;
const frozen=JSON.parse(fs.readFileSync('../scratch/rob-316-mixed-validation-input-033cd059.json','utf8'));
assert.equal(eligible.length,2743);
const index=loadCardIndex(),results=[],cache=new Map();
console.log(JSON.stringify({masterPid:process.pid,actualSavedScenarioRuns:2743}));
for(const entry of eligible){
  let file=cache.get(entry.file);if(!file){file=JSON.parse(fs.readFileSync(entry.file,'utf8'));cache.set(entry.file,file);}
  const scenario=file.scenarios[entry.scenarioIndex],candidate=frozen.candidates[entry.runOrdinal];
  assert.deepEqual(scenario,candidate.changed);assert.equal(scenario.name,entry.scenario);
  const unchanged=JSON.stringify(scenario),result={runOrdinal:entry.runOrdinal,originalCohortOrdinal:entry.originalCohortOrdinal,file:entry.file,card:file.card,scenarioIndex:entry.scenarioIndex,scenario:scenario.name};
  try{const actual=runScenario(scenario,name=>index.definition(name),file.fixtures??{},{explicitChoices:true});
    assert.equal(actual.passed.length,entry.assertions);assert.equal(JSON.stringify(scenario),unchanged);
    result.passed=true;result.assertions=actual.passed.length;
  }catch(error){result.passed=false;result.error={message:error.message,assertion:error.scenarioAssertion??null};}
  results.push(result);
  if(results.length%100===0)console.log(JSON.stringify({completed:results.length,passed:results.filter(r=>r.passed).length}));
}
const report={schema:'ROB316ActualEditedFullScenarios@1',scope:'all actual saved edited scenarios with all original strict assertions',
  head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),scenarios:results.length,
  passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length,
  assertionsPassed:results.filter(r=>r.passed).reduce((sum,r)=>sum+r.assertions,0),results};
fs.writeFileSync('../scratch/rob-316-edited2743-full.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({scenarios:report.scenarios,passed:report.passed,failed:report.failed,assertionsPassed:report.assertionsPassed}));
assert.equal(report.scenarios,2743);assert.equal(report.assertionsPassed,7255);
if(report.failed)process.exitCode=1;
