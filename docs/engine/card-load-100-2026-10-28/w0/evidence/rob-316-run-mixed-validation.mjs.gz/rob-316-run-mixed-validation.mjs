import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {Worker} from 'node:worker_threads';
const outside=path.resolve('../scratch'),inputPath=path.join(outside,'rob-316-mixed-validation-input-033cd059.json');
const raw=fs.readFileSync(inputPath),input=JSON.parse(raw),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const source='033cd059eb5150493015de042309e11ae83ad7da',git=args=>execFileSync('git',args,{encoding:'utf8'}).trim();
assert.equal(sha(raw),'24d77f2afad39206ff9cb4ffaf13286f106d63aec7440e54d2b66ae850059921');
assert.equal(input.source.revision,source);assert.equal(input.source.dirty,false);assert.equal(input.candidates.length,3263);
assert.equal(new Set(input.originalCohortOrdinals).size,3263);assert.equal(input.excludedBasicOnlyResidualCount,161);
const workerPath=path.join(outside,'v8-basic-source-inventory-worker.mjs');
function validateSource(){assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['status','--porcelain']),'');
  for(const file of input.scenarioFileInputs)assert.equal(sha(fs.readFileSync(file.file)),file.sha256);
  for(const file of input.runtime.files)assert.equal(sha(fs.readFileSync(file.file)),file.sha256);
  assert.equal(sha(fs.readFileSync(workerPath)),input.runtime.workerRawSha256);
  assert.equal(sha(fs.readFileSync('docs/ACTIVE.md')),input.frozenActiveSha256);
}
validateSource();
const outputs={results:path.join(outside,'rob-316-mixed-results-033cd059.jsonl'),checkpoint:path.join(outside,'rob-316-mixed-checkpoint-033cd059.json'),summary:path.join(outside,'rob-316-mixed-summary-033cd059.json')};
const results=fs.existsSync(outputs.results)?fs.readFileSync(outputs.results,'utf8').trim().split('\n').filter(Boolean).map(line=>JSON.parse(line)):[];
results.forEach((r,i)=>{assert.equal(r.runOrdinal,i);assert.equal(r.originalCohortOrdinal,input.originalCohortOrdinals[i]);assert.equal(r.inputSha256,sha(raw));assert.equal(r.source,source);});
const started=Date.now(),masterPid=process.pid;let worker,timer,active=results.length,generation=0,finished=false,restarting=false,phase='initializing';
function summarize(){const eligible=results.filter(r=>r.result.eligibleForSavedEdit),prefixFailures=results.filter(r=>r.result.nativePrefixVerified===false),fullFailures=results.filter(r=>r.result.nativePrefixVerified===true&&r.result.fullStrictPass===false);
  return {schema:'ROB316MixedNativeValidation@1',scope:'read-only finite witnesses; no saved edits, omissions, guard normalization or card admission',
    issue:'ROB-316',branch:input.branch,source:input.source,runtime:input.runtime,cohortSha256:input.cohortSha256,inputSha256:sha(raw),
    candidateCount:3263,completed:results.length,complete:results.length===3263,reviewEligibleScenarios:eligible.length,
    reviewEligibleFiles:new Set(eligible.map(r=>r.result.file)).size,reviewProposedFieldAdditions:eligible.reduce((n,r)=>n+input.candidates[r.runOrdinal].additions.length,0),
    originalAssertionsPassed:eligible.reduce((n,r)=>n+(r.result.assertions??0),0),validatedTapReceipts:results.reduce((n,r)=>n+(r.result.nativeReceipts?.length??0),0),
    prefixFailures:prefixFailures.length,fullStrictFailures:fullFailures.length,executionFailures:results.filter(r=>r.result.executionFailure).length,
    timeoutCases:results.filter(r=>r.result.executionFailure?.kind==='timeout').length,inputsUnchanged:results.every(r=>r.result.executionFailure||r.result.inputsUnchanged===true),
    resultsSha256:fs.existsSync(outputs.results)?sha(fs.readFileSync(outputs.results)):null,
    previous161BasicOnlyCasesExcluded:true,historicalPilotPreserved:true,savedEdits:0,omissionRuns:0,cardsAdmitted:0,canonicalAcceptance:false};}
function checkpoint(){const value=summarize();fs.writeFileSync(outputs.checkpoint,JSON.stringify({...value,nextRunOrdinal:results.length,activeRunOrdinal:active,phase,masterPid,elapsedSeconds:Math.round((Date.now()-started)/1000)},null,2)+'\n');return value;}
function save(runOrdinal,result){assert.equal(runOrdinal,results.length);const record={runOrdinal,originalCohortOrdinal:input.originalCohortOrdinals[runOrdinal],source,inputSha256:sha(raw),result};fs.appendFileSync(outputs.results,JSON.stringify(record)+'\n');results.push(record);
  if(results.length%25===0){const value=checkpoint();console.log(JSON.stringify({completed:value.completed,total:3263,reviewEligible:value.reviewEligibleScenarios,prefixFailures:value.prefixFailures,fullFailures:value.fullStrictFailures,executionFailures:value.executionFailures,elapsedSeconds:Math.round((Date.now()-started)/1000)}));}}
function finish(){if(finished)return;finished=true;clearTimeout(timer);validateSource();const value=checkpoint();fs.writeFileSync(outputs.summary,JSON.stringify({...value,all6430ScenarioHashesUnchanged:true,allRuntimeHashesUnchanged:true,activeFrozenHashUnchanged:true,masterPid,elapsedSeconds:Math.round((Date.now()-started)/1000)},null,2)+'\n');console.log(JSON.stringify({...value,masterPid,elapsedSeconds:Math.round((Date.now()-started)/1000)},null,2));}
function failCurrent(kind,message){const c=input.candidates[active];save(active,{file:c.file,card:c.card,scenario:c.original.name,prefix:c.prefix,originalFieldsPreserved:true,eligibleForSavedEdit:false,executionFailure:{kind,message,unproved:true}});}
function arm(myGeneration){clearTimeout(timer);timer=setTimeout(async()=>{if(finished||restarting||myGeneration!==generation)return;restarting=true;failCurrent('timeout','Case exceeded 60000 ms; unproved with no retry or replacement');const previous=worker;generation++;await previous.terminate();checkpoint();start();},60000);}
function start(){if(results.length===3263){finish();return;}restarting=false;active=results.length;phase='initializing';const myGeneration=++generation;
  const current=new Worker(workerPath,{workerData:{inventory:inputPath,start:active},execArgv:[],resourceLimits:{stackSizeMb:4}});worker=current;arm(myGeneration);
  current.on('message',message=>{if(finished||restarting||myGeneration!==generation)return;if(message.kind==='start'){active=message.index;phase='case';arm(myGeneration);}
    else if(message.kind==='result'){clearTimeout(timer);save(message.index,message.result);active=results.length;phase='between-cases';arm(myGeneration);}
    else if(message.kind==='done'){clearTimeout(timer);finish();}});
  current.on('error',async error=>{if(finished||restarting||myGeneration!==generation)return;restarting=true;const initialization=phase==='initializing';failCurrent(initialization?'worker-initialization-error':'worker-error',error.stack??error.message);generation++;await current.terminate();checkpoint();if(initialization){while(results.length<3263){active=results.length;failCurrent('runner-unavailable','Worker initialization failed; remaining case unproved');}finish();}else start();});
  current.on('exit',code=>{if(!finished&&!restarting&&myGeneration===generation&&code!==0){restarting=true;failCurrent('worker-exit','Worker exited '+code+'; unproved');generation++;checkpoint();start();}});
}
console.log(JSON.stringify({source,inputSha256:sha(raw),runtimeSha256:input.runtime.sha256,fixedCandidates:3263,resumeAt:results.length,caseTimeoutMs:60000,workers:1,masterPid}));checkpoint();start();
