import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {Worker} from 'node:worker_threads';
const outside=path.resolve('../scratch'),inputPath=path.join(outside,'v8-mixed-source-pilot-input-9c4fa115.json');
const raw=fs.readFileSync(inputPath),pilot=JSON.parse(raw),source='9c4fa1156fe482b324488d51627cfc15e0d4583a';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),git=args=>execFileSync('git',args,{encoding:'utf8'}).trim();
assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['status','--porcelain']),'');
assert.equal(pilot.cohortSha256,'54dbd297da55ff9a2ba53f676b9fc4e0aeed70dbc1a8bf8f41eb54d766f027f6');
assert.equal(pilot.candidates.length,10);assert.deepEqual(pilot.originalCohortOrdinals,[673,1181,3188,0,4,13,1,2,8,3]);
for(const c of pilot.candidates)assert.equal(sha(fs.readFileSync(c.file)),c.fileSha256);
const previousPackage=JSON.parse(fs.readFileSync('../scratch/v8-basic-source-inventory-package-544d8512.json','utf8'));
const workerPath=path.join(outside,'v8-basic-source-inventory-worker.mjs'),workerRawHash=sha(fs.readFileSync(workerPath));
assert.equal(workerRawHash,previousPackage.artifacts.find(a=>a.file==='v8-basic-source-inventory-worker.mjs').sha256);
const build=JSON.parse(fs.readFileSync('../scratch/v8-basic-source-inventory-worker-build.json','utf8'));
assert.equal(build.unchangedNativeCheckBodySha256,'2cf07513a5dc6dbc5210c3925eac20df3654119bf427b63a74402fe42a18b514');
const results=[];let worker,timer,active=0,restarting=false,finished=false;
function finish(){if(finished)return;finished=true;clearTimeout(timer);assert.equal(results.length,10);
  assert.equal(git(['rev-parse','HEAD']),source);assert.equal(git(['status','--porcelain']),'');
  for(const c of pilot.candidates)assert.equal(sha(fs.readFileSync(c.file)),c.fileSha256);
  const report={schema:'V8MixedSourceFixedTen@1',scope:'read-only fixed ten; no wider validation or saved edits',source:pilot.source,
    cohortSha256:pilot.cohortSha256,pilotInputSha256:sha(raw),workerRawSha256:workerRawHash,
    entireReviewedNativeBlockUnchanged:true,nativeAssertionBlockSha256:build.unchangedNativeCheckBodySha256,
    fixedSelection:pilot.selection,fixedCohortOrdinals:pilot.originalCohortOrdinals,results,
    nativePrefixPass:results.filter(r=>r.nativePrefixVerified===true).length,
    fullStrictPass:results.filter(r=>r.eligibleForSavedEdit===true).length,
    unproved:results.filter(r=>r.eligibleForSavedEdit!==true).length,
    timeoutsOrErrors:results.filter(r=>r.executionFailure).length,savedChanges:0,omissionRuns:0,canonicalAcceptance:false};
  fs.writeFileSync('../scratch/v8-mixed-source-pilot-results-9c4fa115.json',JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report,null,2));
}
function fail(kind,message){const c=pilot.candidates[active];results.push({pilotIndex:active,cohortOrdinal:c.ordinal,file:c.file,card:c.card,
  scenario:c.original.name,eligibleForSavedEdit:false,executionFailure:{kind,message,unproved:true}});}
function arm(){clearTimeout(timer);timer=setTimeout(async()=>{if(restarting||finished)return;restarting=true;fail('timeout','Fixed case exceeded 60000 ms; unproved, no retry or replacement');await worker.terminate();start();},60000);}
function start(){if(results.length===10){finish();return;}restarting=false;active=results.length;
  worker=new Worker(workerPath,{workerData:{inventory:inputPath,start:active},execArgv:[],resourceLimits:{stackSizeMb:4}});arm();
  worker.on('message',message=>{if(restarting||finished)return;if(message.kind==='start'){active=message.index;arm();}
    else if(message.kind==='result'){assert.equal(message.index,results.length);clearTimeout(timer);const c=pilot.candidates[message.index];results.push({pilotIndex:message.index,cohortOrdinal:c.ordinal,...message.result});arm();}
    else if(message.kind==='done')finish();});
  worker.on('error',async error=>{if(restarting||finished)return;restarting=true;fail('worker-error',error.stack??error.message);await worker.terminate();start();});
  worker.on('exit',code=>{if(!finished&&!restarting&&code!==0){restarting=true;fail('worker-exit','Worker exited '+code+'; unproved');start();}});
}
console.log(JSON.stringify({source,cohortSha256:pilot.cohortSha256,fixedCohortOrdinals:pilot.originalCohortOrdinals,
  workerRawSha256:workerRawHash,entireNativeBlockUnchanged:true,caseTimeoutMs:60000}));
start();
