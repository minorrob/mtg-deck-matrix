import hashlib,json,copy
from pathlib import Path
from collections import Counter

outside=Path('../scratch')
raw=(outside/'v8-mixed-source-cohort-9c4fa115.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='54dbd297da55ff9a2ba53f676b9fc4e0aeed70dbc1a8bf8f41eb54d766f027f6'
cohort=json.loads(raw)
basic={'Wastes','Plains','Island','Swamp','Mountain','Forest'}
docs={}
for entry in cohort['scenarioFileInputs']:
    content=Path(entry['file']).read_bytes()
    assert hashlib.sha256(content).hexdigest()==entry['sha256'],entry['file']
    docs[entry['file']]=json.loads(content)
assert len(docs)==6430
mixed=[c for c in cohort['candidates'] if c['newMixedBoard']]
assert len(mixed)==3263
fields=0
for c in mixed:
    doc=docs[c['file']]
    original=doc['scenarios'][c['scenarioIndex']]
    assert doc['card']==c['card'] and original==c['original']
    assert doc.get('fixtures',{})==c['fixtures']
    assert not basic.intersection(c['fixtures'])
    assert original.get('at',{'turn':1,'phase':'MAIN1'})=={'turn':1,'phase':'MAIN1'}
    assert not any(e.get('zone')=='command' for e in original.get('setup',[]))
    counts=Counter(name for entry in original.get('setup',[]) if entry.get('zone')=='battlefield' and entry.get('seat')==0 for name in entry['cards'])
    used=Counter()
    expected_prefix=[]
    for i,step in enumerate(original.get('steps',[])):
        if step.get('tap') not in basic or step.get('seat',0)!=0 or set(step)-{'tap','seat','source','mana'}:break
        name=step['tap'];ordinal=used[name]
        assert ordinal<counts[name]
        source={'zone':'battlefield','index':ordinal}
        if 'source' in step:assert step['source']==source
        expected_prefix.append({'step':i,'name':name,'ordinal':ordinal,'added':'source' not in step})
        used[name]+=1
    assert expected_prefix==c['prefix'] and expected_prefix
    expected=copy.deepcopy(original)
    additions=[]
    for p in expected_prefix:
        if p['added']:
            source={'zone':'battlefield','index':p['ordinal']}
            expected['steps'][p['step']]['source']=source
            additions.append({'step':p['step'],'source':source})
    assert additions==c['additions'] and expected==c['changed']
    fields+=len(additions)
assert fields==7909
results_raw=(outside/'rob-316-mixed-results-033cd059.jsonl').read_bytes()
assert hashlib.sha256(results_raw).hexdigest()=='dbb705847a71a5dd31130e82bd173a68219c8ba75922efe81e6a2abeb41a878e'
rows=[json.loads(line) for line in results_raw.splitlines()]
assert len(rows)==len(mixed)
eligible=[];prefix_failures=0;strict_failures=0;assertions=0;receipts=0
colors={'Wastes':'C','Plains':'W','Island':'U','Swamp':'B','Mountain':'R','Forest':'G'}
for i,(c,row) in enumerate(zip(mixed,rows)):
    assert row['runOrdinal']==i and row['originalCohortOrdinal']==c['ordinal']
    assert row['source']=='033cd059eb5150493015de042309e11ae83ad7da'
    r=row['result']
    assert (r['file'],r['card'],r['scenario'],r['prefix'])==(c['file'],c['card'],c['scenario'],c['prefix'])
    assert r['inputsUnchanged'] and r['originalFieldsPreserved']
    if r['eligibleForSavedEdit']:
        assert r['nativePrefixVerified'] and r['fullStrictPass'] and not r.get('prefixFailure') and not r.get('fullFailure')
        assert len(r['nativeReceipts'])==len(c['prefix'])
        for p,receipt in zip(c['prefix'],r['nativeReceipts']):
            assert (p['step'],p['name'],p['ordinal'])==(receipt['step'],receipt['name'],receipt['index'])
            assert [e['kind'] for e in receipt['events']]==['GameEventCardTapped','GameEventManaPool']
            tapped,mana=[e['fields'] for e in receipt['events']]
            assert tapped['card']['cardId']==mana['source']['cardId']==receipt['sourceId']
            assert tapped['card']['name']==mana['source']['name']==p['name']
            assert tapped['tapped'] and mana['tapped'] and mana['player']['playerId']==0
            assert mana['produced']=={colors[p['name']]:1}
            expected_pool=copy.deepcopy(receipt['beforePool']);expected_pool[colors[p['name']]]+=1
            assert expected_pool==receipt['afterPool']
        assertions+=r['assertions'];receipts+=len(r['nativeReceipts']);eligible.append(c)
    elif not r['nativePrefixVerified']:
        assert r.get('prefixFailure');prefix_failures+=1
    else:
        assert r['fullStrictPass'] is False and r.get('fullFailure');strict_failures+=1
assert (len(eligible),prefix_failures,strict_failures,assertions,receipts)==(2743,52,468,7255,6741)
assert sum(len(row['result']['nativeReceipts']) for row in rows)==7738
assert len({c['file'] for c in eligible})==1521 and sum(len(c['additions']) for c in eligible)==6741
summary=json.loads((outside/'rob-316-mixed-summary-033cd059.json').read_bytes())
for entry in summary['runtime']['files']:
    assert hashlib.sha256(Path(entry['file']).read_bytes()).hexdigest()==entry['sha256'],entry['file']
result={'schema':'RootMixedSourceStructuralAudit@1','source':'e2845fc4b7fdb1b01612d3c46fb08280b2ea501c','cohortSha256':hashlib.sha256(raw).hexdigest(),'allScenarioFileHashesMatched':len(docs),'scenariosIndependentlyAudited':len(mixed),'files':len({c['file'] for c in mixed}),'proposedFields':fields,'allOriginalFieldsAndFixturesPreserved':True,'everyOrdinalFixedBeforeLegality':True,'commandAndAllBasicFixtureOverridesExcluded':True,'scope':'independent structural review only; no native result, saved edit, card admission or gate credit'}
result.update({'nativeResultSource':summary['source']['revision'],'resultHashMatched':True,'allRuntimeFilesMatchRoot':len(summary['runtime']['files']),'eligibleScenarios':len(eligible),'eligibleFiles':1521,'eligibleFields':6741,'originalAssertions':assertions,'nativeReceiptsIndependentlyAudited':receipts,'prefixFailuresRetained':prefix_failures,'strictFailuresRetained':strict_failures,'scope':'independent plan and complete recorded-result audit; no new native execution, saved edit, card admission or gate credit'})
(outside/'v8-mixed-root-structural-audit-e284.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
