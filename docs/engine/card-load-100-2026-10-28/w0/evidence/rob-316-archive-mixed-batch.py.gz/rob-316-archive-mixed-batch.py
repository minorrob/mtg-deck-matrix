from pathlib import Path
import ast,gzip,hashlib,json,re,subprocess

root=Path.cwd();outside=root.parent/'scratch';out=root/'docs/engine/card-load-100-2026-10-28/w0/evidence'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda name:json.loads((outside/name).read_bytes())
before_source='033cd059eb5150493015de042309e11ae83ad7da'
after_source='4995a7cebf3a3086de71862bc572467c15073bf2'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==after_source
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
before=read('rob-316-mixed-before-033cd059.json');after=read('rob-316-mixed-after-4995a7ce.json')
package=read('rob-316-mixed-package-033cd059.json');manifest=read('rob-316-selected1521-manifest.json')
eligible=read('rob-316-mixed-eligible-033cd059.json')['eligible'];diff=read('rob-316-exact2743-diff.json');full=read('rob-316-edited2743-full.json')
assert before['source']['revision']==before_source and after['source']['revision']==after_source
for ledger in [before,after]:
    assert ledger['source']['dirty'] is False and ledger['measurement']['complete']
    assert ledger['scope']['selected']==manifest['names'] and set(ledger['cards'])==set(manifest['names'])
    assert (ledger['measurement']['definitions'],ledger['measurement']['scenarios'],ledger['summary']['abilities'])==(1521,4337,3057)
    assert ledger['measurement']['counterfactual'] is True and ledger['measurement']['choicePolicy']=='explicit'
assert before['source']['inputs']['scripts']==after['source']['inputs']['scripts']
assert (full['scenarios'],full['passed'],full['failed'],full['assertionsPassed'])==(2743,2743,0,7255)
assert (diff['editedFiles'],diff['editedScenarios'],diff['addedSourceFields'])==(1521,2743,6741)
assert set(subprocess.check_output(['git','diff','--name-only',before_source,after_source],text=True).splitlines())=={entry['file'] for entry in diff['files']}
for entry in diff['files']:assert sha((root/entry['file']).read_bytes())==entry['afterSha256']
baseline_pass=set(before['scenarios']);after_pass=set(after['scenarios'])
approved={entry['card']+': '+entry['scenario'] for entry in eligible}
assert len(approved)==2743
assert len(baseline_pass)==4337-before['measurement']['failed']
assert len(after_pass)==4337-after['measurement']['failed']
assert approved<=after_pass
def budget(ledger):
    return sum(d.get('reason')=='probe time budget exceeded' for card in ledger['cards'].values() for ability in card['abilities'] for d in ability.get('counterfactualUnobserved',{}).get('diagnostics',[]))
backlogs=[]
for stem,ledger in [('before-033cd059',before),('after-4995a7ce',after)]:
    lines=(outside/('rob-316-mixed-'+stem+'.log')).read_bytes().decode('utf-8-sig').splitlines()
    failures=[line for line in lines if line.startswith('FAIL ')]
    assert len(failures)==ledger['measurement']['failed']
    record={'source':ledger['source'],'scope':ledger['scope'],'failedScenariosExactLogLines':failures,
            'unprovedAbilities':ledger['summary']['scenarioUnreached'],'checkerExit':1,
            'budgetExceededDiagnostics':budget(ledger),'canonicalAcceptance':False}
    name='rob-316-mixed-'+stem+'-backlog.json';backlogs.append(name)
    (outside/name).write_bytes((json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
pattern_tree=ast.parse((outside/'scan-pool-368a.py').read_text(encoding='utf-8'))
patterns=next(ast.literal_eval(n.value) for n in pattern_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='patterns' for t in n.targets))
archive_names=[entry['file'] for entry in package['artifacts']]+['rob-316-mixed-package-033cd059.json',
 'rob-316-mixed-before-033cd059.json','rob-316-mixed-before-033cd059.log','rob-316-mixed-before-033cd059-verifier.log',
 'rob-316-mixed-after-4995a7ce.json','rob-316-mixed-after-4995a7ce.log','rob-316-mixed-after-4995a7ce-verifier.log',
 'rob-316-selected1521-names.json','rob-316-selected1521-manifest.json','rob-316-selected1521-transport.json',
 'rob-316-exact2743-diff.json','rob-316-edited2743-full.json','rob-316-edited2743-full.log',
 'rob-316-selected1521-check.mjs','rob-316-freeze-selected1521.py','rob-316-apply-exact2743.py','rob-316-edited2743-full.mjs',
 'rob-316-root-actual-4995.json','rob-316-root-actual-audit.mjs','rob-316-root-samples-eaba.json',
 'rob-316-archive-mixed-batch.py']+backlogs
assert len(archive_names)==len(set(archive_names))
archives=[];old={entry['file']:entry for entry in package['artifacts']}
for name in archive_names:
    raw=(outside/name).read_bytes()
    if name in old:assert sha(raw)==old[name]['sha256']
    assert not any(re.search(pattern,raw.decode('utf-8-sig'),re.I) for pattern in patterns),'privacy finding: '+name
    packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
    dest=out/(name+'.gz');dest.write_bytes(packed)
    if name in old:assert sha(packed)==old[name]['gzipSha256']
    archives.append({'rawFile':name,'rawBytes':len(raw),'rawSha256':sha(raw),
                     'path':str(dest.relative_to(root)).replace('\\','/'),'storedBytes':len(packed),
                     'storedSha256':sha(packed),'rawPrivacyScanPassed':True,'gzipRoundtripVerified':True})
comparison={'definitions':1521,'allOriginalScenarios':4337,'abilities':3057,
 'scenarioFailuresBefore':before['measurement']['failed'],'scenarioFailuresAfter':after['measurement']['failed'],
 'abilitiesReachedBefore':before['summary']['scenarioReached'],'abilitiesReachedAfter':after['summary']['scenarioReached'],
 'runtimeRemovalProofBefore':before['summary']['counterfactualReached'],'runtimeRemovalProofAfter':after['summary']['counterfactualReached'],
 'unprovedBefore':len(before['summary']['scenarioUnreached']),'unprovedAfter':len(after['summary']['scenarioUnreached']),
 'newPassingScenarios':len(after_pass-baseline_pass),'lostPassingScenarios':len(baseline_pass-after_pass),
 'editedScenariosAlreadyPassingBefore':len(approved&baseline_pass),'budgetDiagnosticsBefore':budget(before),'budgetDiagnosticsAfter':budget(after),
 'definitionFidelitySmokeProblemsBefore':before['measurement']['problems'],'definitionFidelitySmokeProblemsAfter':after['measurement']['problems'],
 'beforeCheckerExit':1,'afterCheckerExit':1,'beforeCanonicalVerifierExit':1,'afterCanonicalVerifierExit':1}
record={'schema':'ROB316ApprovedMixedSourceBatch@1','issue':'ROB-316','branch':'codex/rob-316-interaction-witnesses',
 'scope':'exact approved explicit source-field witnesses; no card admission, omission-ledger sweep or canonical acceptance',
 'beforeSource':before['source'],'afterSource':after['source'],'namesSha256':manifest['namesSha256'],
 'same1521FullNamesEveryOriginalScenarioAndAbilityRetained':True,'editedScenarios':2743,'editedFiles':1521,'addedSourceFields':6741,
 'originalAssertionsPassed':7255,'unchangedNativeGuardSha256':package['runtime']['nativeAssertionBlockSha256'],
 'unchangedNativeWorkerRawSha256':package['runtime']['workerRawSha256'],'allOriginalFieldsPreserved':True,
 'all520NewRejectsAnd161PriorRejectsUntouched':True,'historicalTenAndFourRefusalsRetained':True,
 'comparison':comparison,'rootIndependentActualGitAudit':read('rob-316-root-actual-4995.json'),
 'rootIndependentElevenSampleAssertions':27,'savedCardDefinitionsChanged':0,'runtimeHelperClassifierGateChanges':0,
 'cardsAdmitted':0,'canonicalAcceptance':False,
 'interactionConfidence':'Finite witnesses do not establish exhaustive interaction support or permit card addition/promotion.',
 'archives':archives}
target=out/'rob-316-mixed-source-batch.json';target.write_bytes((json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
assert not any(re.search(pattern,target.read_bytes().decode('utf-8'),re.I) for pattern in patterns)
print(json.dumps({'comparison':comparison,'archives':len(archives),'privacy':'PASS','gzipRoundtrips':'all verified',
 'record':str(target.relative_to(root)).replace('\\','/'),'recordSha256':sha(target.read_bytes())},indent=2))
