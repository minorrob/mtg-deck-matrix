import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root=pathToFileURL(process.cwd()+'/');
const {loadCardScripts,loadCardScenarios}=await import(new URL('game/tools/engine-cards.mjs',root));
const {cardCheckSource,cardInputHashes}=await import(new URL('game/tools/card-check-policy.mjs',root));
const sha=raw=>createHash('sha256').update(raw).digest('hex'),source=cardCheckSource(process.cwd());
assert.equal(source.revision,'033cd059eb5150493015de042309e11ae83ad7da');assert.equal(source.dirty,false);
const cohortRaw=fs.readFileSync('../scratch/v8-mixed-source-cohort-9c4fa115.json');
assert.equal(sha(cohortRaw),'54dbd297da55ff9a2ba53f676b9fc4e0aeed70dbc1a8bf8f41eb54d766f027f6');
const cohort=JSON.parse(cohortRaw),pilot=JSON.parse(fs.readFileSync('../scratch/v8-mixed-source-pilot-results-9c4fa115.json','utf8'));
for(const file of cohort.scenarioFileInputs)assert.equal(sha(fs.readFileSync(file.file)),file.sha256,'Frozen scenario changed: '+file.file);
const scripts=loadCardScripts().map(e=>e.script),files=loadCardScenarios().map(e=>e.scenarios);
source.inputs=cardInputHashes(scripts,files);assert.deepEqual(source.inputs,cohort.source.inputs);
assert.equal(files.length,6430);assert.equal(files.reduce((n,f)=>n+f.scenarios.length,0),11044);
const candidates=cohort.candidates.filter(c=>c.newMixedBoard===true);
assert.equal(candidates.length,3263);assert.equal(candidates.reduce((n,c)=>n+c.additions.length,0),7909);
assert.equal(new Set(candidates.map(c=>c.file)).size,1689);
const cohortOrdinals=candidates.map(c=>c.ordinal);assert.equal(new Set(cohortOrdinals).size,3263);
for(const c of candidates){const restored=structuredClone(c.changed);for(const addition of c.additions)delete restored.steps[addition.step].source;
  assert.deepEqual(restored,c.original);for(const e of c.existingLiterals)assert.deepEqual(c.changed.steps[e.step].source,c.original.steps[e.step].source);}
assert.equal(cohort.candidates.filter(c=>!c.newMixedBoard).length,161);
const previousPackage=JSON.parse(fs.readFileSync('../scratch/v8-basic-source-inventory-package-544d8512.json','utf8'));
const workerPath=path.resolve('../scratch/v8-basic-source-inventory-worker.mjs'),workerRaw=fs.readFileSync(workerPath);
assert.equal(sha(workerRaw),previousPackage.artifacts.find(a=>a.file==='v8-basic-source-inventory-worker.mjs').sha256);
const build=JSON.parse(fs.readFileSync('../scratch/v8-basic-source-inventory-worker-build.json','utf8'));
assert.equal(build.unchangedNativeCheckBodySha256,'2cf07513a5dc6dbc5210c3925eac20df3654119bf427b63a74402fe42a18b514');
const git=args=>execFileSync('git',args,{encoding:'utf8'}).trim();
const runtimeFiles=git(['ls-files','game/engine']).split('\n').filter(f=>f.endsWith('.mjs')).sort().map(file=>({file,sha256:sha(fs.readFileSync(file))}));
const runtimeChanges=git(['diff','--name-only',cohort.source.revision,source.revision,'--','game/engine']).split('\n').filter(Boolean);
const helper=fs.readFileSync('game/engine/cards/scenario.mjs').toString('utf8').replaceAll('\r\n','\n');
const oldHelper=execFileSync('git',['show',cohort.source.revision+':game/engine/cards/scenario.mjs'],{encoding:'utf8'});
assert.equal(helper,oldHelper);
const activeRaw=fs.readFileSync('docs/ACTIVE.md');
const input={schema:'ROB316FrozenMixedValidation@1',scope:'exact frozen 3263 new mixed candidates only; no edits, omission run, gate or card admission',
  issue:'ROB-316',branch:'codex/rob-316-interaction-witnesses',source,dependency:'e2845fc4b7fdb1b01612d3c46fb08280b2ea501c',
  frozenCohortSource:cohort.source,cohortSha256:sha(cohortRaw),all6430ScenarioHashesUnchanged:true,allRawCardInputsUnchanged:true,
  candidateCount:3263,candidateFiles:1689,proposedReferenceCount:7909,excludedBasicOnlyResidualCount:161,
  originalCohortOrdinals:cohortOrdinals,candidates,scenarioFileInputs:cohort.scenarioFileInputs,
  runtime:{files:runtimeFiles,sha256:sha(Buffer.from(JSON.stringify(runtimeFiles))),changedPathsSincePilot:runtimeChanges,
    scenarioHelperSha256:sha(Buffer.from(helper)),workerRawSha256:sha(workerRaw),nativeAssertionBlockSha256:build.unchangedNativeCheckBodySha256},
  historicalPilot:{source:pilot.source,resultsSha256:sha(fs.readFileSync('../scratch/v8-mixed-source-pilot-results-9c4fa115.json')),
    all10Results:pilot.results,fourUnproved:pilot.results.filter(r=>!r.eligibleForSavedEdit)},
  frozenActiveSha256:sha(activeRaw),fullInteractionConfidenceRule:'No card addition or promotion; finite witness evidence is not exhaustive proof.'};
const raw=Buffer.from(JSON.stringify(input,null,2)+'\n');fs.writeFileSync('../scratch/rob-316-mixed-validation-input-033cd059.json',raw);
fs.writeFileSync('../scratch/rob-316-mixed-validation-binding-033cd059.json',JSON.stringify({...input,candidates:undefined,scenarioFileInputs:undefined},null,2)+'\n');
console.log(JSON.stringify({source,candidates:3263,files:1689,proposedFields:7909,frozenCohortSha256:sha(cohortRaw),inputSha256:sha(raw),
  runtimeSha256:input.runtime.sha256,runtimeChanges,workerRawSha256:sha(workerRaw),nativeBlockUnchanged:true,activeUnchanged:true},null,2));
