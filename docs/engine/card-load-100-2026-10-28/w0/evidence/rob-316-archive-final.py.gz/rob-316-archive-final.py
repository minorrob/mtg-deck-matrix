from pathlib import Path
import ast,gzip,hashlib,json,re,subprocess
root=Path.cwd();outside=root.parent/'scratch';out=root/'docs/engine/card-load-100-2026-10-28/w0/evidence'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert source=='d51bc30b3df2845562fb5884afb675692ffa6081'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
record=json.loads((out/'rob-316-mixed-source-batch.json').read_bytes())
assert len(record['archives'])==49
for entry in record['archives']:
    blob=subprocess.check_output(['git','show','HEAD:'+entry['path']])
    assert sha(blob)==entry['storedSha256']
    raw=gzip.decompress(blob);assert sha(raw)==entry['rawSha256'] and len(raw)==entry['rawBytes']
audit=json.loads((outside/'rob-316-final-input-audit.json').read_bytes())
assert audit['source']['revision']==source and audit['source']['dirty'] is False
legacy=(outside/'rob-316-final-engine-cards.log').read_bytes().decode('utf-8-sig')
assert 'engine-cards: 55 checks passed' in legacy and '6430 definitions' in legacy
assert 'There are 715 Node suites here' in (root/'README.md').read_text(encoding='utf-8')
tree=ast.parse((outside/'scan-pool-368a.py').read_text(encoding='utf-8'))
patterns=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='patterns' for t in n.targets))
artifacts=[]
for name in ['rob-316-final-engine-cards.log','rob-316-final-data-integrity.log','rob-316-final-feature-wiring.log',
 'rob-316-final-asset-versions.log','rob-316-final-service-worker.log','rob-316-final-scope.log','rob-316-final-inventory.log',
 'rob-316-final-input-audit.json','rob-316-final-input-audit.log','rob-316-final-input-audit.mjs','rob-316-archive-final.py']:
    raw=(outside/name).read_bytes();assert not any(re.search(pattern,raw.decode('utf-8-sig'),re.I) for pattern in patterns)
    packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw
    dest=out/(name+'.gz');dest.write_bytes(packed)
    artifacts.append({'path':str(dest.relative_to(root)).replace('\\','/'),'rawSha256':sha(raw),
                      'storedSha256':sha(packed),'rawPrivacyScanPassed':True,'gzipRoundtripVerified':True})
final={'schema':'ROB316FinalCandidateEvidence@1','issue':'ROB-316','testedCleanSource':source,
 'dependency':'dacd3803a9d3c590ccaf19b30e728f7349c50f8a','historicalBefore':'033cd059eb5150493015de042309e11ae83ad7da',
 'historicalAfter':'4995a7cebf3a3086de71862bc572467c15073bf2','inputAudit':audit,
 'all49ArchiveGitBlobHashesAndRawRoundtripsVerified':True,
 'legacyEngineCards':{'exit':0,'checks':55,'definitions':6430,'originalScenarios':11044,'strictG3Acceptance':False},
 'metadata':{'dataIntegrity':'50 variants / 50 profiles','featureWiring':131,'assetVersions':136,'serviceWorker':9,
             'READMEExistingNodeSuites':715,'inventoryArtifacts':60,'inventoryDrift':False,
             'scopeFrozenNames':8514,'scopeDefinitionStatusFinal':2715,'scopeDefinitionStatusUndefined':5799},
 'nativePolicyMutationsRepeated':False,'reason':'runtime/helper/reader/probe bytes unchanged; data-only literal source additions',
 'savedCardDefinitionChanges':0,'newCardAdmissions':0,'canonicalAcceptance':False,'artifacts':artifacts}
target=out/'rob-316-final-candidate.json';target.write_bytes((json.dumps(final,indent=2)+'\n').encode('utf-8'))
assert not any(re.search(pattern,target.read_bytes().decode('utf-8'),re.I) for pattern in patterns)
print(json.dumps({'testedSource':source,'archiveGitHashes':49,'legacyChecks':55,'metadata':'PASS','privacy':'PASS',
                  'additionalArchivedReceipts':len(artifacts),'finalRecordSha256':sha(target.read_bytes())},indent=2))
