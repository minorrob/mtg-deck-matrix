import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const root=pathToFileURL(process.cwd()+'/');
const {loadCardIndex,loadCardScripts,loadCardScenarios}=await import(new URL('game/tools/engine-cards.mjs',root));
const {cardCheckSource,cardInputHashes}=await import(new URL('game/tools/card-check-policy.mjs',root));
const source=cardCheckSource(process.cwd());assert.equal(source.revision,'9c4fa1156fe482b324488d51627cfc15e0d4583a');assert.equal(source.dirty,false);
const scripts=loadCardScripts().map(e=>e.script),files=loadCardScenarios().map(e=>e.scenarios),index=loadCardIndex();
source.inputs=cardInputHashes(scripts,files);
const names=[...new Set(files.flatMap(f=>f.scenarios.flatMap(s=>(s.setup??[]).filter(e=>e.zone==='battlefield').flatMap(e=>e.cards))))].sort();
const definitions={};
for(const name of names){const definition=index.definition(name);if(!definition){definitions[name]=null;continue;}
  definitions[name]={types:definition.types??[],manaTriggers:(definition.abilities??[]).filter(a=>a.trigger?.manaAbility).map(a=>({id:a.id,text:a.text,trigger:a.trigger}))};}
const result={source,definitions:definitions,scenarioCount:files.reduce((n,f)=>n+f.scenarios.length,0)};
fs.writeFileSync('../scratch/v8-mixed-source-metadata-9c4fa115.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({source,battlefieldNames:names.length,scenarios:result.scenarioCount}));
