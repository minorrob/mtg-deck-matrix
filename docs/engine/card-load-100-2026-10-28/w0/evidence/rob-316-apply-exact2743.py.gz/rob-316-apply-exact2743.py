from pathlib import Path
from copy import deepcopy
from collections import defaultdict
import hashlib,json,subprocess

root=Path.cwd();outside=root.parent/'scratch';source='033cd059eb5150493015de042309e11ae83ad7da'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda name:json.loads((outside/name).read_bytes())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
package_raw=(outside/'rob-316-mixed-package-033cd059.json').read_bytes()
assert sha(package_raw)=='ff15f1cd7e2ed5d142cc5909dbcdc89e0343c5e3b0d711c6e461fdd89fd90582'
package=json.loads(package_raw);frozen=read('rob-316-mixed-validation-input-033cd059.json')
eligible_raw=(outside/'rob-316-mixed-eligible-033cd059.json').read_bytes()
assert sha(eligible_raw)==next(a['sha256'] for a in package['artifacts'] if a['file']=='rob-316-mixed-eligible-033cd059.json')
eligible=json.loads(eligible_raw)['eligible'];before=read('rob-316-mixed-before-033cd059.json');manifest=read('rob-316-selected1521-manifest.json')
assert before['source']['revision']==source and before['source']['dirty'] is False and before['measurement']['complete']
assert before['scope']['selected']==manifest['names'] and set(before['cards'])==set(manifest['names'])
assert (before['measurement']['definitions'],before['measurement']['scenarios'])==(1521,4337)
assert before['measurement']['counterfactual'] is True and before['measurement']['choicePolicy']=='explicit'
assert len(eligible)==2743 and len({e['file'] for e in eligible})==1521 and sum(len(e['additions']) for e in eligible)==6741
for entry in frozen['runtime']['files']:assert sha((root/entry['file']).read_bytes())==entry['sha256']
assert sha((root/'docs/ACTIVE.md').read_bytes())==frozen['frozenActiveSha256']
originals={}
for entry in frozen['scenarioFileInputs']:
    raw=(root/entry['file']).read_bytes();assert sha(raw)==entry['sha256'],entry['file']
    originals[entry['file']]=(raw,json.loads(raw))
byfile=defaultdict(list)
for entry in eligible:byfile[entry['file']].append(entry)
pending=[];audit=[]
for file,entries in sorted(byfile.items()):
    raw,original=originals[file];changed=deepcopy(original);edits=[]
    for entry in entries:
        candidate=frozen['candidates'][entry['runOrdinal']]
        assert (candidate['file'],candidate['card'],candidate['scenarioIndex'],candidate['ordinal'])==(file,entry['card'],entry['scenarioIndex'],entry['originalCohortOrdinal'])
        index=entry['scenarioIndex'];assert original['scenarios'][index]==candidate['original']
        assert original['card']==entry['card'] and original['scenarios'][index]['name']==entry['scenario']
        assert entry['additions']==candidate['additions']
        changed['scenarios'][index]=deepcopy(candidate['changed'])
        edits.extend({'scenarioIndex':index,'scenario':entry['scenario'],**addition} for addition in entry['additions'])
    restored=deepcopy(changed)
    for edit in edits:
        assert 'source' not in original['scenarios'][edit['scenarioIndex']]['steps'][edit['step']]
        assert restored['scenarios'][edit['scenarioIndex']]['steps'][edit['step']]['source']==edit['source']
        del restored['scenarios'][edit['scenarioIndex']]['steps'][edit['step']]['source']
    assert restored==original
    blob=(json.dumps(changed,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    pending.append((root/file,blob));audit.append({'file':file,'beforeSha256':sha(raw),'afterSha256':sha(blob),
        'originalScenariosRetained':len(original['scenarios']),'allOriginalFieldsPreserved':True,'edits':edits})
assert sum(len(entry['edits']) for entry in audit)==6741
for target,blob in pending:target.write_bytes(blob)
changed_paths=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())
assert changed_paths==set(byfile)
audit_by_file={entry['file']:entry for entry in audit}
for file,(raw,original) in originals.items():
    actual_raw=(root/file).read_bytes();actual=json.loads(actual_raw)
    if file not in byfile:assert actual_raw==raw
    else:
        restored=deepcopy(actual)
        for edit in audit_by_file[file]['edits']:del restored['scenarios'][edit['scenarioIndex']]['steps'][edit['step']]['source']
        assert restored==original
eligible_pairs={(e['file'],e['scenarioIndex']) for e in eligible}
cohort=read('v8-mixed-source-cohort-9c4fa115.json')
for candidate in cohort['candidates']:
    if (candidate['file'],candidate['scenarioIndex']) not in eligible_pairs:
        assert json.loads((root/candidate['file']).read_bytes())['scenarios'][candidate['scenarioIndex']]==candidate['original']
for entry in frozen['runtime']['files']:assert sha((root/entry['file']).read_bytes())==entry['sha256']
report={'schema':'ROB316ExactSourceFieldDiff@1','sourceBefore':source,'reviewPackageSha256':sha(package_raw),
 'selectedCards':1521,'selectedAllOriginalScenarios':4337,'editedScenarios':2743,'editedFiles':1521,'addedSourceFields':6741,
 'all6430OriginalDocumentsStructurallyPreserved':True,'allOtherScenarioFilesByteExact':True,
 'all520NewRejectedScenariosUntouched':True,'all161PriorRejectedScenariosUntouched':True,
 'allRuntimeFilesUnchanged':True,'onlyApprovedFilesChanged':True,'savedCardDefinitionsChanged':0,'cardsAdmitted':0,'files':audit}
(outside/'rob-316-exact2743-diff.json').write_bytes((json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({key:value for key,value in report.items() if key!='files'},indent=2))
